# 確定済み共通前提

Source: docs/business-design/README.md 最終段落。

PostgreSQL is the current target database and execution environment. Alder, Raw SQL Rules and Serene are the implementation/review contracts described in [adoption](../adoption.md); implementation structure and surface choices do not add business requirements.
