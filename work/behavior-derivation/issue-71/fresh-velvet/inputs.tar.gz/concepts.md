# Velvet Concept definitions

固定版: 6b64e3b99845a315a394fee8e500564c3631e2af。全てlifecycle=definedの設計本文。IDは原文のstatement ID。reviewStateは含めない。

## active-black

Source: docs/concepts/active-black/concept.json

転送済みの黒伝のうち、まだ取り消されていない現在有効な黒伝。

### active-black-is-current-black

Active Black は、転送済みの黒伝のうち、まだ取り消されていない現在有効な黒伝である。

### black-row-background

黒伝とは、転送元データをそのまま転送先へ流した転送先行である。

### not-source-row

Active Black は、転送元行そのものではなく、転送済みの黒伝を指す。

### context-is-transfer-setting-destination-link-source-key

Active Black は、Transfer Setting と Destination Link の文脈で、source key に対する現在有効な黒伝を示す。

### decision-material

Active Black は、二重転送防止、更新相当の転送、取消や訂正の判断材料として参照される。

### identify-current-black

現在有効な黒伝を特定できるようにする。

### identify-red-transfer-target

immutable transfer model の Red Transfer で反転対象として参照すべき黒伝を特定できるようにする。

### provide-validity-boundary

転送済みの黒伝がまだ有効かどうかを判断するための概念境界を提供する。

### represent-disappearance-after-cancel

黒伝が Red Transfer または Physical Delete Transfer によって取り消された後には存在しない状態を表現する。

### support-lineage-trace

Lineage と併用される場合、反転対象となる転送先行を追跡しやすくする。

### not-lineage-management

Active Black は、転送先行の由来追跡を管理しない。

### not-work-item-selection

Active Black は、転送対象行を決定しない。

### not-transfer-state

Active Black は、転送依頼、転送実行、または転送処理状態を管理しない。

### not-red-transfer-definition

Active Black は、Red Transfer の意味を定義しない。

### not-sql-or-calculation

Active Black は、赤伝 SQL の生成手順、実行手順、黒伝や赤伝の金額計算、符号反転列、列マッピングを定義しない。

### not-mutable-log

Active Black は、mutable transfer model の処理ログや監査ログではない。

### requires-transferred-black

Active Black は、転送済みの黒伝が存在する場合にだけ存在し得る。

### unique-per-context

Active Black は、Transfer Setting と Destination Link の文脈における source key 単位で最大1つである。

### none-for-unlinked-source

連携されていない転送元行には Active Black は存在しない。

### none-for-cancelled-black

取り消し済みの黒伝には Active Black は存在しない。

### red-transfer-removes-active-black

immutable transfer model では、Red Transfer が成功したタイミングで、反転対象だった黒伝は Active Black ではなくなる。

### new-black-becomes-active

immutable transfer model で赤伝後に新しい黒伝が追加された場合、その新しい黒伝が Active Black になる。

### physical-delete-removes-active-black

mutable transfer model では、Physical Delete Transfer が成功したタイミングで、対応する黒伝は Active Black ではなくなる。

### separate-axis-from-lineage

Active Black は、現在有効な黒伝を示す別軸の概念である。

### red-transfer-needs-active-black

immutable transfer model で Red Transfer を行うには、どの黒伝を反転するかを特定する必要がある。

### destination-link-context-rationale

同じ Transfer Setting と source key から複数の Destination Link へ転送する場合、Active Black は Destination Link の文脈ごとに区別する。

### lineage-is-related-but-separate

Lineage は immutable transfer model における転送先行の由来追跡であり、Active Black は現在有効な黒伝を示す。両者は併用されることがあるが、役割は異なる。

### transfer-model-changes-when-active-black-disappears

immutable transfer model では Red Transfer が成功したタイミングで、mutable transfer model では Physical Delete Transfer が成功したタイミングで、対象だった Active Black は存在しなくなる。

### Defined relationships

- lineage / uses: Active Black は immutable transfer model で現在有効な黒伝を特定するときに Lineage と併用されることがある。

- lineage / is-distinct-from: Lineage は転送先行の由来を記録し、Active Black は現在有効な黒伝を特定する。

- destination-link / uses: Active Black は Destination Link の文脈で現在有効な黒伝を区別する。

- red-transfer / uses: Red Transfer は反転対象となる Active Black を必要とする。

- physical-delete-transfer / uses: Physical Delete Transfer は物理削除対象となる Active Black を必要とする。

## black-transfer

Source: docs/concepts/black-transfer/concept.json

転送元の現在値を転送先へコピーし、黒伝を作る通常転送

### black-transfer-source-destination

Black Transfer とは、転送元の現在値を転送先へコピーすることである。

### black-transfer-source-destination-reference

Black Transfer は、転送時点で参照した転送元データのスナップショットを転送先へ作る。

### black-transfer-destination-row

黒伝とは、Black Transfer によって作られた転送先行である。

### black-insert-transfer

Black Insert Transfer とは、Black Transfer のうち、新しい黒伝を追加する転送表現である。

### black-transfer-update-mutable-model

Black Update Transfer とは、Black Transfer のうち、`mutable transfer model` で既存の黒伝を直接 UPDATE して現在値を反映する転送表現である。

### black-insert-transfer-immutable-model

`immutable transfer model` では、Black Transfer は Black Insert Transfer として表現される。

### black-insert-transfer-insert-only-model

`insert_only transfer model` で転送元の現在行が存在し Active Black が存在しない場合、既存の Black Insert Transfer と同じ表現で黒伝を追加する。

### black-insert-transfer-update-mutable-model

`mutable transfer model` では、Black Transfer は状況に応じて Black Insert Transfer または Black Update Transfer として表現される。

### black-transfer-destination-link-setting-source-context-state

Black Transfer は、同じ `Transfer Setting`、`Destination Link`、`source key` の文脈で、同じ転送元状態を二重転送しない。

### reference-decide-active-black

転送対象判定は、既存の `Active Black` を参照して二重転送を避けられる必要がある。

### black-transfer-create-active

Black Transfer が成功すると、作成または更新された黒伝は `Active Black` になる。

### black-transfer-lineage-create-non-mutable-model-active

`immutable transfer model` または `insert_only transfer model` の Black Insert が成功すると、`Active Black` に加えて `Lineage` も作成される。

### black-transfer-source-destination-2

Black Transfer は、転送元の現在値を転送先へコピーする通常転送を説明する。

### black-transfer-destination

Black Transfer は、転送先に黒伝を追加または更新する。

### black-insert-transfer-update

Black Transfer は、Black Insert Transfer と Black Update Transfer の上位概念として扱う。

### black-transfer-reference-active

Black Transfer は、転送対象判定が二重転送を避けるために参照した既存の `Active Black` に対応できる必要がある。

### black-transfer-create-active-2

Black Transfer は、成功時に作成または更新された黒伝を `Active Black` として扱えるようにする。

### black-transfer-lineage-create-non-mutable-model

Black Transfer は、`immutable transfer model` と `insert_only transfer model` の Black Insert では成功時に `Lineage` を作成できるようにする。

### not-black-transfer-red-define

Black Transfer は、`Red Transfer` の意味を定義しない。

### not-black-transfer

Black Transfer は、取消や訂正を表現しない。

### not-black-transfer-target-row-decide

Black Transfer は、転送対象行を決定しない。

### not-transfer-target-context-decide-work-item

転送対象かどうかは、`Transfer Target Decision` で判断する。

### not-black-transfer-define-active

Black Transfer は、`Active Black` の保存形式を定義しない。

### not-black-transfer-lineage-define

Black Transfer は、`Lineage` の保存形式を定義しない。

### not-black-transfer-produce-define-sql

Black Transfer は、転送 SQL の生成手順や実行手順を定義しない。

### not-black-transfer-destination-define-source-mapping

Black Transfer は、source-to-destination mapping の具体的な計算手順を定義しない。

### black-transfer-source-destination-3

Black Transfer は、転送元の現在値を転送先へコピーする。

### black-transfer

Black Transfer は、取消や訂正のための反転行を作らない。

### black-insert-transfer-immutable-model-2

`immutable transfer model` では、Black Transfer は Black Insert Transfer として黒伝を追加する。

### black-insert-transfer-insert-only-model-2

`insert_only transfer model` で Active Black がない追加転送候補では、Black Transfer は Black Insert Transfer として黒伝を追加する。Active Black がある場合は Transfer Target Decision が no-op とする。

### black-insert-transfer-mutable-model-active

`mutable transfer model` の追加転送候補では、Black Transfer は Black Insert Transfer として黒伝を追加する。

### black-update-transfer-mutable-model-active

`mutable transfer model` の更新転送候補では、Black Transfer は Black Update Transfer として既存の黒伝を直接 UPDATE して現在値を反映する。

### black-transfer-destination-link-setting-source-context-state-2

Black Transfer は、同じ `Transfer Setting`、`Destination Link`、`source key` の文脈で、同じ転送元状態を二重転送しない。

### black-transfer-destination-link-setting-context-decide-source

Black Transfer は、同じ `Transfer Setting`、`Destination Link`、`source key` の文脈における既存の `Active Black` を前提にした転送対象判定の結果に対応できる必要がある。

### black-transfer-active

Black Transfer が成功した場合、対応する黒伝は `Active Black` になる。

### black-transfer-lineage-create-non-mutable-model-2

`immutable transfer model` または `insert_only transfer model` の Black Insert では、成功時に `Lineage` が作成される。

### lineage-create-mutable-transfer-model

`mutable transfer model` では、この文書で定義する `Lineage` は作成されない。

### black-transfer-source-destination-reference-not-guarantee-match

Black Transfer Is the Normal Snapshot Transfer: Black Transfer は、転送元の現在値を転送先へコピーする。 これは、転送時点で参照した転送元データを転送先に残すスナップショットである。 ここでいうスナップショットは、転送時点で参照した値を転送先へ作るという意味であり、転送元の将来の現在値と一致し続けることを保証しない。

### black-insert-transfer-update-destination-row-depends-model

Black Transfer Depends on Transfer Model: Black Transfer は、transfer model によって転送先への反映方法が変わる。 `immutable transfer model` では Black Insert Transfer として新しい黒伝を追加する。 `insert_only transfer model` では Active Black がない初回だけ同じ Black Insert Transfer を使い、作成済みなら Transfer Target Decision が no-op とする。 `mutable transfer model` では Black Insert Transfer または Black Update Transfer として表現される。判定正本は `Transfer Target Decision` が所有する。

### black-transfer-destination-link-setting-source-context-state-3

Black Transfer Must Avoid Duplicate Transfer: Black Transfer は、同じ `Transfer Setting`、`Destination Link`、`source key` の文脈で、同じ転送元状態を二重転送しない。 既に有効な黒伝が存在する場合、それは同じ `Transfer Setting`、`Destination Link`、`source key` の文脈における `Active Black` として参照できる必要がある。 `Active Black` は、Black Transfer が新しい黒伝を作るべきか、既に有効な黒伝があるかを判断する材料になる。

### black-transfer-destination-record-exists-successful-creates-active

Successful Black Transfer Creates Active Black: Black Transfer が成功すると、転送先に黒伝が存在する。 その黒伝がまだ取り消されていない場合、`Active Black` として扱われる。 `mutable transfer model`、`immutable transfer model`、`insert_only transfer model` の初回 Black Insert は、いずれも転送成功時に `Active Black` を記録できる必要がある。

### black-transfer-lineage-physical-delete-destination-row-source

Non-mutable Black Insert Also Creates Lineage: `immutable transfer model` と `insert_only transfer model` の Black Insert では、生成した転送先行と転送元データソースの論理行の対応を `Lineage` として追跡する。`mutable transfer model` では、転送先行を直接更新または `Physical Delete Transfer` で削除するため、この文書で定義する `Lineage` は作成しない。

### Defined relationships

- active-black / uses: Black Transfer は二重転送を防ぐために Active Black を参照し、生成または更新した黒伝を Active Black にする。

- destination / uses: Black Transfer は Destination 側に黒伝を作る。

- lineage / records: immutable または insert_only の Black Insert では、成功した Black Transfer が転送元データ行と黒伝の対応を Lineage として記録する。

- red-transfer / is-distinct-from: Black Transfer は現在の転送元値をコピーして黒伝を作り、Red Transfer は反転する赤伝を作る。

## destination-link

Source: docs/concepts/destination-link/concept.json

転送設定のデータソースを特定の転送先仕様へ接続する設定

### destination-link-transfer-setting

転送先リンクとは、`転送設定` のデータソースを特定の `転送先仕様` へ接続する設定である。

### destination-link-transfer-setting-2

`Transfer Setting` は、複数の Destination Link を持ってよい。

### destination-link-source

Destination Link は、同じ転送元データソースのスナップショットを複数 `Destination` へ一貫して流すための接続定義である。

### destination-link-source-2

Destination Link は、どの `Destination` へ送るか、どの順序で送るか、転送元列を `Destination` 列へどう対応させるかを定義する。

### destination-link-transfer-setting-produce-source-key

Destination Link は、同じ `Transfer Setting` `source key` から生成される宛先別の行役割を識別する。

### destination-link-transfer-setting-reference

同じ `Destination` が、同一 `Transfer Setting` から複数の Destination Link として参照されてもよい。

### destination-link-reference-mapping

同じ `Destination` を複数回参照する場合、各 Destination Link は異なる役割、実行順、または mapping を持つ別の転送単位として扱う。

### destination-link

Destination Link は、接続先の `Destination` を示す。

### destination-link-transfer-setting-3

Destination Link は、`Transfer Setting` 内での宛先別の実行順を持ってよい。

### destination-link-source-mapping

Destination Link は、宛先別の source-to-destination mapping を持つ。

### destination-link-transfer-setting-produce-source-key-row

Destination Link は、`Transfer Setting` の `source key` から生成される宛先別の `destination row key` の対応を示せる必要がある。

### destination-link-2

Destination Link は、宛先別の差分比較除外列を持つ。

### destination-link-produce-hold-source-mapping-aot-sql

Destination Link は、source-to-destination mapping に依存する AOT 生成済み転送 SQL を保持してよい。

### not-destination-link-source-define

Destination Link は、転送元データソースそのものを定義しない。

### not-destination-link-define

Destination Link は、`Destination` の転送先テーブル仕様を定義しない。

### not-destination-link-transfer-run-create-manage

Destination Link は、`Transfer Run` の作成、スケジューリング、実行タイミングを管理しない。

### not-destination-link-state-manage

Destination Link は、転送実行状態や転送結果を管理しない。

### not-destination-link-dirty-key-define

Destination Link は、`Dirty Key` の意味や登録方法を定義しない。

### not-destination-link-lineage-record-active-black

Destination Link は、`Active Black` や `Lineage` の記録そのものではない。

### not-destination-link-transfer-setting-define-source-key

Destination Link は、`Transfer Setting` の `source key` を再定義しない。

### destination-link-transfer-setting-requires-one

Destination Link は、必ず1つの `Transfer Setting` に属する。

### destination-link-reference-requires-one

Destination Link は、必ず1つの `Destination` を参照する。

### destination-link-transfer-setting-mapping

Destination Link は、`Transfer Setting` と `Destination` の組み合わせだけでなく、宛先別の役割や mapping を表す。

### destination-link-transfer-setting-4

同じ `Transfer Setting` から同じ `Destination` へ複数の Destination Link を定義してもよい。

### destination-link-reference

同じ `Destination` を複数回参照する Destination Link は、それぞれ独立した転送単位として扱う。

### destination-link-transfer-setting-base-sql-not-define

Destination Link の mapping は、`Transfer Setting` の基礎 SQL の結果を `Destination` の列へ対応させるためのものであり、`Destination` の物理仕様を再定義しない。

### destination-link-transfer-setting-not-define-source-key

Destination Link は、`Transfer Setting` の `source key` を再定義しない。

### destination-link-lineage-context-distinguish-active-black-row

`Lineage` と `Active Black` は、`Destination` 単体ではなく Destination Link の文脈で destination row を区別する。

### destination-link-transfer-setting-produce-hold-source-mapping

source-to-destination mapping に依存する生成済み転送 SQL を保持する場合、その所属先は `Transfer Setting` 単体でも `Destination` 単体でもなく、Destination Link である。

### destination-link-transfer-setting-source-reference-produce-distinguish

Destination Link Connects One Data Source to One Destination Role: `Transfer Setting` は、転送元データソースを定義する。 `Destination` は、転送先テーブルへ書き込むために必要な転送先側の仕様を定義する。 Destination Link は、その間に立ち、同じデータソースをどの `Destination` のどの役割へ流すかを定義する。 これにより、1つのデータソースの同じスナップショットから、複数の `Destination` 行を一貫して生成できる。 `Transfer Setting` の `source key` は、データソースの再評価単位を識別する正本である。 Destination Link は、その `source key` から生成される宛先別の行役割と `destination row key` の対応を示す。 たとえば、1つの売上 `source key` から、仕訳、借方科目、貸方科目の3つの destination row を生成する場合、それぞれを別の Destination Link として区別する。借方科目と貸方科目が同じ `Destination` を参照する場合でも、Destination Link が異なれば別の転送単位として扱う。

### destination-link-lineage-transfer-setting-active-black-trace

Same Destination May Be Referenced More Than Once: 1つのデータソースから、同じ `Destination` に対して複数の行を生成したい場合がある。 この場合、`Destination` は同じでも、Destination Link ごとに役割、実行順、mapping が異なる。 そのため、同一 `Transfer Setting` 内で同じ `Destination` を複数 Destination Link として参照できる必要がある。 この区別は、`Lineage` と `Active Black` の文脈でも必要である。`Destination` が同じでも、Destination Link が異なれば、由来追跡や現在有効な黒伝の判断は別の文脈として扱う。

### black-insert-transfer-update-destination-link-physical-delete

Mapping-Dependent Generated SQL Belongs to the Destination Link: AOT 生成された転送 SQL のうち、source-to-destination mapping に依存する SQL は、`Transfer Setting` 単体にも `Destination` 単体にも属さない。 転送 SQL は、`Transfer Setting` の基礎 SQL、`Destination` の列や transfer model、Destination Link の mapping や宛先別設定の組み合わせで決まる。 そのため、mapping に依存する生成済み転送 SQL を保持する場合、その自然な所属先は Destination Link である。 `Red Transfer` は転送先側の元黒行から赤伝を作るため、Destination Link の source-to-destination mapping には依存しない。 そのため、生成済み `Red Transfer` SQL は Destination 側に属する。 保持する SQL の具体的な種類は実装 Issue で決める。たとえば Black Insert Transfer、Black Update Transfer、`Physical Delete Transfer` など、mapping に依存する転送表現ごとの SQL を保持することがある。

### destination-link-owns-diff-compare-excluded-columns

差分比較除外列は、転送対象判定で比較を無視する転送先列である。Destination に置き、さらに Destination Link で上書きできるようにすると、正本と例外の関係が複雑になる。Destination Link は宛先別の役割や mapping を表すため、特定の転送だけ比較を無視したい列も Destination Link の設定で表現できる。したがって、差分比較除外列の管理場所は Destination Link に一本化し、Destination は差分比較除外列を持たない。

### Defined relationships

- transfer-setting / depends-on: Destination Link は必ず1つの Transfer Setting に属する。

- destination / uses: Destination Link は Transfer Setting のデータソースを1つの Destination へ接続する。

- destination / must-not-redefine: Destination Link のマッピングは Destination の物理的な意味を再定義しない。

## destination

Source: docs/concepts/destination/concept.json

転送先テーブルへ書き込むために必要な転送先側の仕様

### destination-red-transfer-produce

Destination とは、転送先テーブルへ書き込むために必要なテーブル、列、キー、採番、転送モデル、赤伝生成に関する転送先側の仕様である。

### destination-definition

Destination Definition とは、Destination を名前で再利用できるように永続化した定義である。

### destination-table

`destination table` とは、転送によって実際に行が書き込まれる物理的な転送先テーブルである。

### destination-reference-table

Destination は `destination table` そのものではなく、転送アプリケーションがそのテーブルへ書き込むために参照する仕様である。

### destination

Destination は、スキーマ名などを含む完全修飾された転送先テーブル名で一意に特定できる。

### destination-transfer-setting

Destination は、`Transfer Setting` から独立した転送先仕様である。

### destination-transfer-setting-not-define

Destination は、`Transfer Setting` ごとに再定義しない。

### destination-transfer-setting-reference

Destination は、複数の `Transfer Setting` から参照されてよい。

### destination-ddl

Destination は、転送先テーブルの物理 DDL そのものではない。転送アプリケーションが必要とする転送先仕様である。

### destination-table-transfer

Destination は、`destination table` を transfer 専用のシステムテーブルとして所有しない。

### destination-2

Destination は、スキーマ名などを含む完全修飾された転送先テーブル名を持つ。

### destination-3

Destination は、転送先テーブルへ書き込む列を識別できる情報を持つ。

### destination-row

Destination は、転送先行を後から識別できるキー定義を持つ。

### destination-row-create

Destination は、転送先行を新規作成する際に、転送先側で採番値を得るための式または規則を持ってよい。

### destination-transfer-model

Destination は、転送先の保存モデルとして transfer model を示す。

### destination-red-transfer-produce-2

Destination は、赤伝生成に必要な転送先側の列情報を持ってよい。

### destination-red-transfer-immutable-model

Destination が `immutable transfer model` で `Red Transfer` を扱う場合、数量や金額など、少なくとも1つの符号反転列を識別できる必要がある。

### destination-red-transfer-produce-hold-aot-sql

Destination は、AOT 生成された `Red Transfer` SQL を保持してよい。

### destination-posting-date-lower-bound-hook

Destination は、必要に応じて日付下限制御の補正関数hookを持ってよい。

### not-destination-source-define-sql

Destination は、転送元 SQL の列名、構造、抽出条件を定義しない。

### not-destination-define-source-mapping

Destination は、source-to-destination mapping を定義しない。

### not-destination-link-context-source-mapping

source-to-destination mapping は、`Destination Link` の文脈で扱う。

### not-destination-transfer-setting-define

Destination は、`Transfer Setting` ごとの実行順序や有効無効を定義しない。

### not-destination-state-manage

Destination は、転送実行状態、転送結果、実行履歴を管理しない。

### not-destination-lineage-active-black-row-trace-red

Destination は、転送先行の由来追跡や、赤伝時に参照すべき現在有効な黒を管理しない。

### not-destination-produce-define-sql

Destination は、SQL 生成手順や SQL 実行手順を定義しない。

### not-destination-transfer-setting-define-2

Destination は、差分比較除外列、つまり転送対象判定で比較を無視する列を定義しない。

### not-destination-transfer-setting-model

Destination は、`Transfer Setting` の都合で転送先テーブル、キー、採番、transfer model の意味を変えない。

### destination-4

Destination は、転送先の保存モデルを表す。

### destination-source

Destination は、転送元ごとに作らない。

### destination-not-define-package-definition

Destination の転送先テーブル名は、同じ package 内で一意であり、同じ物理転送先テーブルを複数の Destination Definition として再定義しない。

### destination-transfer-setting-2

Destination は、`Transfer Setting` から再利用されてよい。

### destination-transfer-setting-3

Destination は、`Transfer Setting` に依存してはならない。

### destination-transfer-setting-reference-2

`Transfer Setting` は、Destination を参照してよいが、Destination の意味を上書きしてはならない。

### destination-produce-transfer-model-sql

Destination の transfer model は、後続の転送 SQL 生成と転送実行の前提になる。

### destination-red-transfer-immutable-model-2

`immutable transfer model` の Destination は、`Red Transfer` のために少なくとも1つの符号反転列を識別できる必要がある。

### destination-row-reference

Destination のキー定義は、転送先行を後から参照できる必要がある。

### destination-5

Destination の採番式は、転送先定義側で管理する。

### destination-transfer-setting-base-sql-row-key

`Transfer Setting` の基礎 SQL は、Destination の採番式を使って `destination row key` を投影してよい。

### destination-transfer-setting-base-sql-engine-row-key

transfer engine は、`Transfer Setting` の基礎 SQL に採番式や `destination row key` を暗黙に追加しない。

### destination-ddl-2

Destination は、転送先テーブルの物理 DDL そのものではない。

### destination-has-transfer-model-yaml-immutable-mutable

Destination は、転送先行の保存方法を決める `transfer_model` を持つ。値は `immutable` または `mutable` である。

### destination-row-red-transfer-produce-not-define-immutable

`immutable` は、転送先行を直接更新・削除せず、履歴として積み増す転送モデルである。更新時は元黒を赤伝化して新黒を追加し、削除時は元黒を赤伝化する。

### destination-row-physical-delete-produce-not-define-mutable

`mutable` は、転送先行を直接更新・削除する転送モデルである。更新時は転送先行を直接更新し、削除時は転送先行を物理削除する。

### destination-lineage-physical-delete-transfer-row-red-black

Destination の `transfer_model` は、転送先行をどう保存し、どう取り消し、どう更新するかを決める保存モデルである。既に転送が行われた後の変更は通常編集ではなく migration-level decision として扱い、履歴解釈、`Lineage` の不完全性、`Active Black` の扱いが変わることを人間に警告する。

### destination-red-transfer-black-produce-owns-column-information

Destination は、赤伝生成に必要な転送先側の符号反転列情報を持ってよい。符号反転列は、既に転送されている元黒を転送先側でどう反転するかを示す仕様であり、具体的な SQL 生成手順ではない。

### destination-link-posting-date-lower-bound-red-transfer

`Red Transfer` は、既に転送されている元黒行を転送先側で反転して生成する。AOT 生成された赤伝SQLを保持する場合、その所属先は `Destination Link` ではなく Destination である。

### destination-red-transfer-reference-hold-has-columns-public

Destination は、転送先テーブルへ書き込む列を識別できる必要がある。同じ物理転送先テーブルを複数の Destination Definition として再定義すると、transfer model、キー定義、採番式、赤伝列情報の正本が分裂する。

### destination-row-reference-has-key-definition

Destination は、転送先行を後から参照できる必要がある。キーはサロゲートキー、自然キー、複合キーを取り得る。

### destination-transfer-setting-row-base-sql-create-has

Destination は、転送先行を新規作成する際に採番値を得るための式または規則を持ってよい。採番式は転送先仕様であり、`Transfer Setting` の基礎 SQL へ暗黙には追加されない。

### destination-transfer-setting-reference-independent-from-journal-account

Destination は複数の `Transfer Setting` から参照されてよい。そのため、Destination は `Transfer Setting` の子概念ではなく、独立した転送先側の仕様として扱う。

### Defined relationships

- transfer-setting / is-distinct-from: Destination は Transfer Setting の子ではなく、独立した転送先側の仕様である。

- transfer-setting / must-not-redefine: Destination は Transfer Setting 固有の都合で転送先側の意味を変えない。

- posting-date-lower-bound / uses: Destination は締め済み期間に対する計上日補正が必要な場合に日付下限制御を持つことがある。

## dirty-key-processing

Source: docs/concepts/dirty-key-processing/concept.json

変更キーごとの処理結果を、転送実行記録と転送先リンクの文脈で記録する概念

### dirty-key-processing-processed-record-id

変更キー処理結果とは、処理済みの `変更キー` とその処理結果を記録する概念である。

### dirty-key-processing-transfer-run-trace

Dirty Key Processing は、どの `Transfer Run` で処理されたかを追跡できる。

### dirty-key-processing-transfer-setting-context-trace

Dirty Key Processing は、どの `Transfer Setting` の文脈で処理されたかを追跡できる。

### destination-link-dirty-key-processing-context-trace

Dirty Key Processing は、どの `Destination Link` の文脈で処理されたかを追跡できる。

### destination-link-dirty-key-processing-id

Dirty Key Processing は、`Destination Link` ID を持つ必要がある。

### dirty-key-processing-record-work-item

Dirty Key Processing は、`Work Item` の処理結果を記録できる。

### dirty-key-processing-processed-record-reference

Dirty Key Processing は、二重転送防止のために参照される処理済み記録である。

### dirty-key-processing-management

Dirty Key Processing は、`Dirty Key` Management そのものではない。

### dirty-key-processing-processed-record-id-2

Dirty Key Processing は、処理済みの `Dirty Key` ID を記録する。

### dirty-key-processing-transfer-run-record

Dirty Key Processing は、処理した `Transfer Run` を記録する。

### dirty-key-processing-transfer-setting-context-record

Dirty Key Processing は、処理した `Transfer Setting` の文脈を記録する。

### destination-link-dirty-key-processing-context-record

Dirty Key Processing は、処理した `Destination Link` の文脈を記録する。

### destination-link-dirty-key-processing-record-id

Dirty Key Processing は、`Destination Link` ID を記録する。

### dirty-key-processing-record-work-item-2

Dirty Key Processing は、`Work Item` の処理結果を記録する。

### dirty-key-processing-red-transfer-trace-work-item

Dirty Key Processing は、追加、更新、赤伝追加、削除、無視など、`Work Item` がどう処理されたかを追跡できるようにする。

### dirty-key-processing-processed-work-item

Dirty Key Processing は、`Work Item` を作るときに、処理済み `Dirty Key` を除外できるようにする。

### destination-link-dirty-key-processing-transfer-setting-context

Dirty Key Processing は、同じ `Dirty Key` を同じ `Transfer Setting` と `Destination Link` の文脈で二重転送しないための判断材料を提供する。

### dirty-key-processing-trace

Dirty Key Processing は、監査やデバッグで、`Dirty Key` がどう扱われたかを追跡できるようにする。

### not-dirty-key-processing-change-detection-history-management

Dirty Key Processing は、`Dirty Key` Management の変更検知履歴を変更しない。

### not-dirty-key-processing-processed-state

Dirty Key Processing は、`Dirty Key` 自体に処理済み状態を書き込まない。

### not-dirty-key-processing-define

Dirty Key Processing は、`Dirty Key` の登録方法を定義しない。

### not-dirty-key-processing-work-item

Dirty Key Processing は、`Work Item` の処理結果を作らない。

### not-black-transfer-dirty-key-processing-lineage-red

Dirty Key Processing は、`Black Transfer`、`Red Transfer`、`Active Black`、`Lineage` の保存形式を定義しない。

### not-dirty-key-processing-produce-define-sql

Dirty Key Processing は、転送 SQL の生成手順や実行手順を定義しない。

### dirty-key-processing-record-id

Dirty Key Processing は、`Dirty Key` ID を記録する。

### dirty-key-processing-transfer-run-record-2

Dirty Key Processing は、`Transfer Run` を記録する。

### destination-link-dirty-key-processing-record-id-2

Dirty Key Processing は、`Destination Link` ID を記録する。

### dirty-key-processing-record

Dirty Key Processing は、処理結果を記録する。

### dirty-key-processing-processed-record-work-item

`Work Item` を作るとき、既に Dirty Key Processing に記録されている `Dirty Key` は処理済みとして除外する。

### destination-link-dirty-key-processing-transfer-run-record

`Work Item` の処理が終わった後、Dirty Key Processing に `Dirty Key` ID、`Destination Link` ID、処理結果、`Transfer Run` を記録する。

### dirty-key-processed-state

`Dirty Key` 自体には処理済み状態を書き込まない。

### destination-link-dirty-key-processing-transfer-setting-processed

Dirty Key Processing の処理済み記録は、`Transfer Setting` と `Destination Link` の文脈を持つ。

### destination-link-dirty-key-processing-transfer-setting

同じ `Dirty Key` でも、`Transfer Setting` または `Destination Link` が異なれば別の Dirty Key Processing として扱われ得る。

### dirty-key-processing-processed-change-detection-history-record

Dirty Key Processing は、処理済み記録であり、変更検知履歴ではない。

### dirty-key-processing-processed-change-detection-history-record-2

Dirty Key Is Immutable Change Detection: `Dirty Key` Management は、変更検知履歴としてイミュータブルに扱う。 同じキーに対して複数の `Dirty Key` が追加されてよい。 そのため、どの `Dirty Key` が処理済みかを `Dirty Key` 自体に書き戻してはならない。 Dirty Key Processing は、`Dirty Key` とは別に処理済み記録を持つための概念である。

### dirty-key-processing-processed-record-prevents-duplicate-transfer

Dirty Key Processing Prevents Duplicate Transfer: `Work Item` は `Dirty Key` から作られる。 しかし、既に処理済みの `Dirty Key` を再び `Work Item` として処理すると、二重転送につながる。 `Work Item` を作るときは、Dirty Key Processing に記録済みの `Dirty Key` を除外する必要がある。 この除外により、`Dirty Key` 自体を変更せずに二重転送を防止できる。

### destination-link-dirty-key-processing-transfer-run-setting

Processing Is Destination Link Scoped: `Dirty Key` は転送アプリケーション全体で共有される変更検知履歴である。 同じ `Dirty Key` でも、`Transfer Setting` が異なれば処理対象や転送判断は異なり得る。 また、1つの `Transfer Run` は1つの `Transfer Setting` を対象にするが、その `Transfer Setting` は複数の `Destination Link` を持ち得る。 そのため、Dirty Key Processing は `Transfer Setting` だけでなく、`Destination Link` の文脈を持つ必要がある。 `Destination Link` ID がないと、ある `Dirty Key` がどの宛先別設定で処理済みなのかを区別できず、二重転送防止の粒度が粗くなる。

### black-insert-transfer-update-dirty-key-processing-physical

Processing Records the Decision: Dirty Key Processing は、`Dirty Key` が処理済みかどうかだけでなく、`Work Item` がどの結果として処理されたかを追跡できる。 たとえば、無視した、Black Insert Transfer で追加した、Black Update Transfer で更新した、`Red Transfer` で赤伝を追加した、`Red Transfer` 後に Black Insert Transfer した、`Physical Delete Transfer` で物理削除した、などの処理結果を記録できる。 この情報は、監査、デバッグ、二重転送防止に有用である。

### Defined relationships

- dirty-key / depends-on: Dirty Key Processing は処理済みの Dirty Key ID を記録する。

- transfer-run / records: Dirty Key Processing はどの Transfer Run が Dirty Key を処理し、どの処理結果になったかを記録する。

- transfer-setting / depends-on: Dirty Key Processing は Transfer Setting の文脈で管理される。

- destination-link / depends-on: Dirty Key Processing は、1つの Transfer Run が複数の Destination Link を処理できるため Destination Link ID を記録する。

- dirty-key / is-distinct-from: Dirty Key はイミュータブルな変更検知履歴であり、Dirty Key Processing は処理済み状態の記録である。

## dirty-key

Source: docs/concepts/dirty-key/concept.json

変更が起きた可能性のある発生元行を識別する変更検知履歴

### dirty-key-source-table-package

ここで言う Source Table とは、Dirty Key が発生したテーブルを一意に識別できる完全名である。スキーマ名など、同じ package 内でテーブルを一意に特定するために必要な情報を含む。

### key-source-table

ここで言う Key とは、Source Table 内の該当行を一意に識別する情報である。複合キーにも対応する。

### transfer-target-dirty

Dirty とは、追加、更新、削除など何らかの理由により、転送対象として再評価されるべき可能性があることを示す。

### dirty-key-change-detection-history-record-source-table

Dirty Key とは、変更が起きた可能性のある Source Table と Key の組み合わせを記録する変更検知履歴である。

### dirty-key-change-detection-history-management

Dirty Key Management とは、Dirty Key をイミュータブルな変更検知履歴として管理する仕組みである。

### dirty-key-transfer-target

Dirty Key は、転送対象かどうかを確定しない。

### transfer-target-context-decide-work-item

転送対象かどうかは、`Transfer Target Decision` で判断する。

### dirty-key-change-detection-history-management-2

Dirty Key Management は、転送アプリケーション全体で共有される変更検知履歴として扱う。

### dirty-key-hold-management-source-table

Dirty Key Management は、Source Table と Key の組み合わせで発生元行を識別できる情報を保持する。

### dirty-key-management

Dirty Key Management は、単一キーだけでなく複合キーに対応する。

### dirty-key-change-detection-management

Dirty Key Management は、変更検知または登録の時点を説明できる時刻情報を持つ。

### responsibility-b2adcf08

ただし、その時刻情報を厳密なイベント順、登録確定順、処理順の保証として扱ってはならない。

### dirty-key-management-cdc-db

Dirty Key Management への登録方法はスコープ外である。CDC、DBトリガー、手動追加等、なんらかの方法で追加する仕組みは別途必要である。

### dirty-key-management-2

Dirty Key Management への登録は非同期、並列で実行されることを想定する。

### dirty-key-management-transfer

Dirty Key Management への登録は transfer 中も常に追加され続ける可能性を想定する。

### dirty-key-transfer-management

transfer は、Dirty Key Management への追記を長時間妨げる前提で設計してはならない。

### not-dirty-key-state

Dirty Key は転送指示、転送状態、転送結果ではない。

### not-dirty-key

Dirty Key は、追加、更新、削除のどれが起きたかを確定する責務を持たない。

### not-dirty-key-active-black-processed-red-transfer

Dirty Key は、転送済み、処理済み、重複、転送履歴、赤伝対象の現在有効な黒を管理しない。

### dirty-key-change-detection-history-management-3

Dirty Key Management はイミュータブルな変更検知履歴として扱う。

### dirty-key-record-management-source-table

Dirty Key Management は、同一 Source Table と Key の Dirty Key を複数記録できる。

### change-detection-source-table-key

変更検知、再通知、再評価のために、同じ Source Table と Key を何度追加してもよい。

### dirty-key-transfer

transfer は、Dirty Key 自体に転送進捗や処理結果を書き戻さない。

### dirty-key-transfer-management-2

transfer は Dirty Key Management にあるシーケンスの大小を登録確定順、イベント順、処理順として扱ってはならない。

### dirty-key-change-detection-history-state-record-management

Dirty Key Management に同一キーのユニーク制約を置かない理由: Dirty Key Management は変更検知履歴であり、現在状態テーブルではない。 同じ Source Table と Key の組み合わせに対して、複数回の変更検知、再通知、手動投入が発生してよい。 そのため、同一 Source Table と Key の Dirty Key を複数記録できる必要がある。 また、登録時に存在チェックを行わないことで、外部 producer が低コストに追記できる。

### dirty-key-decide-management

Dirty Key Management が変更理由を問わない理由: Dirty Key Management は、元テーブル上のイベント種別を転送上の操作種別へ変換しない。 論理削除のように、元テーブル上は更新でも、データソースクエリから取得されなくなることで転送上は削除相当になる場合がある。 そのため、変更理由が分かったとしても、Dirty Key Management はそれを転送判断の正本として扱わない。 Dirty Key Management が表すのは、何らかの変更により、そのキーを再評価すべき可能性がある、ということだけである。

### Defined relationships

- transfer-run / is-distinct-from: Dirty Key は転送指示、転送状態、処理結果ではない。

## duplicate-control

Source: docs/concepts/duplicate-control/concept.json

変更キーを転送作業対象にするか、重複転送として転送不要にするかを分ける判断境界。

### destination-link-dirty-key-duplicate-control-transfer-setting

重複転送制御とは、同じ転送設定、転送先リンク、source key の文脈で、転送すべき変更キーと重複転送として転送不要な変更キーを分ける判断である。

### dirty-key-processing-active-black-processed-transfer-trace

有効黒伝は現在有効な黒伝があるかどうかを判断し、変更キー処理結果は処理済み変更キーと処理結果を追跡する。

### dirty-key-decide

既に同じ転送判断として扱われた変更キーを再び転送しない。

### work-item-target-decide

重複ではない変更キーを転送対象判定へ渡し、転送作業対象を作る判断材料にする。

### not-dirty-key-define

変更キーの登録方法は定義しない。

### not-active-black-transfer-define

重複転送制御は、転送対象判定における列の値評価や具体的な比較式を定義しない。

### not-define-db

DB制約、ロック、トランザクション、リトライ方式は定義しない。

### dirty-key-processed-state

変更キー自体には処理済み状態を書き込まない。

### dirty-key-processed-record-active-black

有効黒伝は処理済み変更キーの記録ではない。

### dirty-key-processing-processed-record

処理済み変更キーの記録は変更キー処理結果に残す。

### Defined relationships

- active-black / uses: 現在有効な黒伝があるかを判断するため。

- dirty-key-processing / uses: 処理済み変更キーを除外し、処理結果を追跡するため。

- work-item / supports: 転送作業対象を作るときの判断材料になるため。

- transfer-target-decision / uses: 重複ではない変更キーを、転送対象にするか転送不要にするかの判定へ渡すため。

## lineage

Source: docs/concepts/lineage/concept.json

転送先行と、その転送先行を生成または記録した転送元情報を紐づけ、元ネタと実行文脈を追跡できるようにする概念。

### lineage-is-transfer-result-trace

Lineage は、転送先行と、その転送先行の転送元を紐づける追跡情報である。

### exists-after-transfer

Lineage は、転送が実行され、転送先行が生成または記録された場合に存在する。

### absent-before-destination-row

転送先行が生成または記録されていない場合、Lineage は存在しない。

### tracks-source-key-to-destination-row

Lineage は、転送時点で参照された source key と、生成された destination row の対応を記録する。

### black-transfer-source-key-meaning

Black Transfer では、source key は転送元データソースの論理行または再評価単位を識別する。

### red-transfer-source-key-meaning

Red Transfer では、source key は反転対象となった既存の転送先行を識別する。

### identify-source

Lineage は、転送元を識別できる情報を持つ。

### identify-destination-row

Lineage は、転送先行を識別できる情報を持つ。

### reference-transfer-run

Lineage は、どの Transfer Run によって転送されたかを参照できる。

### reference-transfer-setting

Lineage は、どの Transfer Setting に基づく転送かを参照できる。

### reference-destination-link

Lineage は、どの Destination Link の文脈で destination row が生成されたかを参照できる。

### trace-for-audit-debug

Lineage は、転送元と転送先行の対応を監査やデバッグで追跡できる形で保持する。

### destination-row-starting-point

Lineage は、destination table の行を起点に、その行の source key、Transfer Run、Destination Link をたどれるようにする。

### not-current-source-value

Lineage は、転送元行の現在値を表すものではなく、転送元行の現在値を管理しない。

### not-destination-current-state

Lineage は転送先行の現在状態を管理しない。

### not-transfer-selection

Lineage は、どの行を次に転送すべきかを決定しない。転送対象かどうかは Transfer Target Decision で判断する。

### not-transfer-request-or-execution

Lineage は、転送依頼や転送実行そのものを管理しない。

### not-active-black-selection

Lineage は、赤伝時に参照すべき現在有効な黒を決定しない。現在有効な黒伝の選択は Lineage そのものではなく別の概念で扱う。

### not-mutable-model-ledger

Lineage は mutable transfer model の転送先行を追跡する正本としては扱わない。

### not-generic-log

Lineage は処理ログ一般、監査ログ一般、実行ログ一般ではない。

### source-to-destination-zero-to-many

Lineage は、転送元から転送先行への対応を 0..N として扱う。

### destination-to-source-zero-or-one

Lineage は、転送先行から転送元への対応を 0..1 として扱う。

### belongs-to-transfer-run

Lineage は、必ず1つの Transfer Run に紐づく。

### belongs-to-destination-link-context

Lineage は、必ず1つの Destination Link の文脈に紐づく。

### guarantees-correspondence-not-values

Lineage が保証するのは source key と destination row の対応関係であり、転送元の値スナップショットや現在値との一致ではない。

### lineage-model-boundary

Lineage は immutable transfer model と insert_only transfer model の Black Insert で存在し、転送先行を直接更新または削除する mutable transfer model では持たない。

### created-result-is-needed

転送していなければ、紐づける転送先行が存在しない。そのため Lineage は転送対象候補や転送依頼ではなく、転送された結果を追跡するために存在する。

### updates-create-multiple-results

転送元は、更新、削除、訂正、取消により複数回転送されることがあるため、転送元から転送先行への Lineage は 0..N として扱う。

### destination-row-cardinality-axis

Lineage の cardinality は destination row 単位で考えるため、1つの destination row から見た source key は 0..1 として扱う。

### mutable-overwrite-loses-history

mutable transfer model では転送先行を直接更新または削除するため、上書きした時点で転送先行に対する履歴としての Lineage を持ちようがない。

### Defined relationships

- transfer-run / records: Lineage は転送先行を生成した Transfer Run を記録する。

- transfer-setting / records: Lineage は転送先行がどの Transfer Setting のもとで生成されたかを記録する。

- destination-link / records: Lineage は転送先行を生成した Destination Link の文脈を記録する。

## physical-delete-transfer

Source: docs/concepts/physical-delete-transfer/concept.json

mutable transfer model で既存の転送先行を物理削除する削除表現

### physical-delete-transfer-destination-row-mutable-model

Physical Delete Transfer とは、`mutable transfer model` で既存の転送先行を物理削除する転送表現である。

### physical-delete-transfer-source-exists-active-black

Physical Delete Transfer は、転送元の現在値が存在せず、既存の `Active Black` が存在する場合に使われる。

### black-transfer-physical-delete

Physical Delete Transfer は、`Black Transfer` ではない。

### physical-delete-transfer-red

Physical Delete Transfer は、`Red Transfer` ではない。

### physical-delete-transfer-mutable-model

`mutable transfer model` の削除相当は、Physical Delete Transfer として表現する。

### physical-delete-transfer-target-active-black

Physical Delete Transfer が成功すると、削除対象だった `Active Black` は存在しなくなる。

### physical-delete-transfer-mutable-model-2

Physical Delete Transfer は、`mutable transfer model` における削除相当の表現を説明する。

### physical-delete-transfer-target-active-black-2

Physical Delete Transfer は、削除対象となる既存の `Active Black` を必要とする。

### physical-delete-transfer-destination-row-active-black

Physical Delete Transfer は、`Active Black` に対応する既存の転送先行を物理削除する。

### physical-delete-transfer-target-active-black-3

Physical Delete Transfer は、成功時に削除対象だった `Active Black` をなくす。

### not-physical-delete-transfer-define-immutable-model

Physical Delete Transfer は、`immutable transfer model` の削除表現を定義しない。

### not-red-transfer-context-immutable-model

`immutable transfer model` の削除相当は、`Red Transfer` の文脈で扱う。

### not-physical-delete-transfer-target-row-decide

Physical Delete Transfer は、転送対象行を決定しない。

### not-transfer-target-context-decide-work-item

転送対象かどうかは、`Transfer Target Decision` で判断する。

### not-physical-delete-transfer-define-active-black

Physical Delete Transfer は、`Active Black` の保存形式を定義しない。

### not-lineage-physical-delete-transfer-create

Physical Delete Transfer は、`Lineage` を作成しない。

### not-physical-delete-transfer-produce-define-sql

Physical Delete Transfer は、削除 SQL の生成手順や実行手順を定義しない。

### physical-delete-transfer-mutable-model-3

Physical Delete Transfer は `mutable transfer model` でのみ発生する。

### physical-delete-transfer-red-immutable-model

`immutable transfer model` では、削除相当は Physical Delete Transfer ではなく `Red Transfer` として表現する。

### physical-delete-transfer-source-exists-active-black-2

Physical Delete Transfer は、転送元の現在値が存在せず、`Active Black` が存在する場合に成立する。

### physical-delete-transfer-black

Physical Delete Transfer は、黒伝を追加しない。

### physical-delete-transfer-red-2

Physical Delete Transfer は、赤伝を追加しない。

### physical-delete-transfer-destination-row

Physical Delete Transfer は、転送先行を物理削除する。

### physical-delete-transfer-black-target-active

Physical Delete Transfer の成功後、削除対象だった黒伝は `Active Black` ではなくなる。

### lineage-physical-delete-transfer-create

Physical Delete Transfer は `Lineage` を作成しない。

### black-transfer-physical-delete-red-destination-row-source

Mutable Delete Is Not Black or Red: `Black Transfer` は、転送元の現在値を転送先へ反映する転送表現である。 `Red Transfer` は、`immutable transfer model` で既存黒伝を反転した赤伝を追加する削除または訂正表現である。 `mutable transfer model` の削除相当は、転送元の現在値を反映するものでも、赤伝を追加するものでもない。 そのため、`mutable transfer model` で既存の転送先行を物理削除する表現を Physical Delete Transfer として分ける。

### physical-delete-transfer-destination-row-black-target-removes

Physical Delete Removes Active Black: Physical Delete Transfer は、削除対象となる既存の `Active Black` を必要とする。 Physical Delete Transfer が成功すると、対応する転送先行は物理削除される。 そのため、削除対象だった黒伝は `Active Black` ではなくなる。

### Defined relationships

- active-black / uses: Physical Delete Transfer は物理削除対象となる Active Black を必要とする。

- destination / uses: Physical Delete Transfer は既存の転送先行を物理削除する。

- red-transfer / is-distinct-from: mutable delete は Physical Delete Transfer であり、immutable delete は Red Transfer で表現する。

## posting-date-lower-bound

Source: docs/concepts/posting-date-lower-bound/concept.json

締め済み期間へ新しい転送先行を増やさないため、計上したい日付を計上可能な日付へ補正する概念。

### posting-date-lower-bound-destination-row

日付下限制御とは、転送先行を計上してよい日付の下限値に基づく日付補正制御である。

### destination-row

締め済みの日付より前または同日のデータは、新しい転送先行としてその日付に追加してはならない。

### destination-row-2

計上したい日付が下限値より前または同日の場合、転送先行を拒否するのではなく、計上可能な最小日付へ補正する。

### posting-date-lower-bound-red-transfer-black

日付下限制御は、黒伝計上時にも赤伝計上時にも考慮する必要がある。

### destination-posting-date-lower-bound-exists

日付下限制御は、すべての `Destination` に存在するとは限らない。

### meaning-5dda4fa6

締め管理テーブル、締め粒度、締め判定ロジックはアプリケーションに依存する。

### posting-date-lower-bound-destination-row-closed-period

日付下限制御は、締め済み期間に対して新しい転送先行が増えないようにするための計上日付制御を表す。

### destination-posting-date-lower-bound

日付下限制御は、計上したい日付を、その `Destination` で許可される計上日付へ補正できる必要がある。

### posting-date-lower-bound

日付下限制御は、必要に応じて店舗、部門、会社などの業務単位ごとに異なる下限値を扱える必要がある。

### destination-transfer-sql

`transfer` は、利用者または転送先設定が指定した補正関数を転送SQLへ組み込める仕組みを提供する。

### posting-date-lower-bound-destination-record

日付下限制御は、補正が発生した事実を任意の転送先列へ記録できてよい。

### not-posting-date-lower-bound-define

日付下限制御は、締め日マスタそのものを定義しない。

### not-posting-date-lower-bound-define-2

日付下限制御は、締め管理テーブルの物理構造を定義しない。

### not-posting-date-lower-bound-transfer

日付下限制御は、締め日判定ロジックそのものを `transfer` 内で所有しない。

### not-transfer

`transfer` は、店舗別、会社別、月締め、日締めなどの業務固有ロジックを内蔵しない。

### not-posting-date-lower-bound-red-transfer-define

日付下限制御は、赤伝の符号反転列を定義しない。

### not-destination-link-posting-date-lower-bound-define

日付下限制御は、`Destination Link` の source-to-destination mapping を再定義しない。

### destination-row-closed-period

締め済み期間へ新しい転送先行を増やしてはならない。

### posting-date-red-transfer-black

計上日付補正は、黒伝と赤伝の両方に適用できる必要がある。

### destination-posting-date-lower-bound-mutable-transfer-model

`mutable transfer model` では、日付下限制御を表現できないため、日付下限制御が必要な `Destination` ではエラーとして扱う。

### closed-period-red-transfer-black-immutable-model

`immutable transfer model` では、締め済み期間の訂正や取消は、計上可能な日付へ補正された赤伝または黒伝として表現する。

### destination-row-posting-date

計上日付補正の結果は、転送先行に書き込まれる計上日付として扱われる。

### destination-row-target

補正関数の引数は、補正対象となる転送先行の列から取得する。

### transfer

補正関数は利用者側が定義する。`transfer` は補正関数の意味を解釈しない。

### closed-dates-must-not-receive-new-rows

Closed Dates Must Not Receive New Rows: 日締めや月締めによって締められた日付には、それ以上データが増えてはならない。 たとえば `2026-04-30` まで締められている場合、`2026-04-10` のデータをそのまま追加してはならない。 この場合、追加不能として転送を止めるのではなく、締められていない最小の日付、たとえば `2026-05-01` として計上する。

### destination-link-posting-date-lower-bound-red-transfer

Red Transfer Needs The Same Control: 黒伝では、`Destination Link` の mapping 後に作られる転送先行の論理形に対して日付補正を適用できる。 赤伝は転送先の元黒行を反転して生成する。 そのため、赤伝でも同じく、補正対象となる転送先行の論理形に対して日付補正を適用する。 日付下限制御は、黒伝と赤伝で別々の参照元を持つ概念ではない。 補正関数の引数は、常に補正対象となる転送先行の列から取得する。

### destination-row-reference-transfer-should-provide-hook-not

Transfer Should Provide A Hook, Not Own Business Logic: 締め日判定は業務固有である。 たとえば店舗ごとに締め日が異なる場合、店舗IDと計上したい日付を補正関数へ渡し、許可された日付ならそのまま返し、不許可なら計上可能な最小日付を返す、という設計が考えられる。 ```text fn_journal_date(shop_id, journal_date) ``` 全社共通の締め日であれば、店舗IDの引数は不要かもしれない。 重要なのは、`transfer` が締め日ロジックそのものや締め管理テーブルを管理するのではなく、設定された補正関数を転送SQLへ組み込む仕組みを提供することである。 補正関数の定義は、アプリケーション側の関数として管理される。 `transfer` は、その関数名と転送先行のどの列を引数として渡すかを扱う。 同じアプリケーションで同じ補正関数を複数の `Destination` から使う場合、関数名や説明をマスタ化してよい。 ただし、そのマスタは補正関数を参照しやすくするための設定であり、締め管理テーブルや締め判定ロジックそのものではない。

### lineage-posting-date-lower-bound-destination-row-adjustment

Adjustment Notice Is Optional: 日付補正が発生した事実は、運用や調査で分かりやすい方がよい。 ただし、すべての転送先テーブルが補正通知用の列を持つとは限らない。 そのため、補正通知は必須ではなく任意の転送先列へ書き込める補助機能として扱う。 補正理由の詳細は日付下限制御の責務ではない。 必要な調査は `Lineage` や転送先行の値から確認する。

### Defined relationships

- destination / depends-on: 日付下限制御は Destination ごとに設定され、書き込み対象の destination row の列を使用する。

## red-transfer

Source: docs/concepts/red-transfer/concept.json

immutable transfer model で取消または訂正が必要な場合に、黒伝を反転した赤伝を追加する転送表現

### destination-row-source-black-transfer

黒伝とは、転送元データをそのまま転送先へ流した転送先行である。

### destination-row-red-transfer-black

赤伝とは、黒伝を反転して訂正や取消を表現する転送先行である。

### red-transfer-black-immutable-model

赤伝転送とは、`immutable transfer model` で取消または訂正が必要な場合に、既に転送されている黒伝を反転した赤伝を追加する転送表現である。

### red-transfer-mutable-model

Red Transfer は、`mutable transfer model` では発生しない。

### red-transfer-target-active-black

Red Transfer は、赤伝対象となる `Active Black` を必要とする。

### red-transfer-target

Red Transfer は、数量や金額など、少なくとも1つの符号反転対象を必要とする。

### red-transfer-target-active-black-2

Red Transfer が成功すると、反転対象だった `Active Black` は存在しなくなる。

### lineage-red-transfer-destination-row-target-produce-create

Red Transfer が成功すると、反転対象だった既存の転送先行と、生成された赤伝の `Lineage` が作成される。

### red-transfer-immutable-model

Red Transfer は、`immutable transfer model` における訂正や取消の表現を説明する。

### red-transfer-black-target

Red Transfer は、反転対象となる黒伝を必要とする。

### red-transfer-black-target-2

Red Transfer は、黒伝から赤伝を作るために、少なくとも1つの符号反転対象を必要とする。

### red-transfer-target-active-black-3

Red Transfer は、成功時に反転対象だった `Active Black` をなくす。

### red-transfer-black

Red Transfer は、赤伝が黒伝の反転として扱われることを説明する。

### lineage-red-transfer-trace

Red Transfer は、成功時に赤伝の由来を `Lineage` として追跡できるようにする。

### not-red-transfer-define-mutable-model

Red Transfer は、`mutable transfer model` の取消表現を定義しない。

### not-red-transfer-target-row-decide

Red Transfer は、転送対象行を決定しない。

### not-transfer-target-context-decide-work-item

転送対象かどうかは、`Transfer Target Decision` で判断する。

### not-red-transfer-define-active-black

Red Transfer は、`Active Black` の保存形式を定義しない。

### not-lineage-red-transfer-define

Red Transfer は、`Lineage` の保存形式を定義しない。

### not-red-transfer-produce-define-sql

Red Transfer は、赤伝 SQL の生成手順や実行手順を定義しない。

### not-red-transfer-define

Red Transfer は、符号反転列、引き継ぎ列、列マッピングの具体的な計算手順を定義しない。

### red-transfer-immutable-model-2

Red Transfer は `immutable transfer model` でのみ発生する。

### physical-delete-transfer-red-mutable-model

`mutable transfer model` では、取消は Red Transfer ではなく `Physical Delete Transfer` で表現する。

### red-transfer-target-exists-active-black

Red Transfer は、反転対象となる `Active Black` が存在する場合にだけ成立する。

### red-transfer-target-2

Red Transfer は、少なくとも1つの符号反転対象がある場合にだけ成立する。

### red-transfer-black-target-active

Red Transfer の成功後、反転対象だった黒伝は `Active Black` ではなくなる。

### lineage-red-transfer-destination-row-source-target-produce

Red Transfer の成功後、生成された赤伝は反転対象だった既存の転送先行を転送元とする `Lineage` を持つ。

### red-transfer-black-physical-delete

Red Transfer は、元の黒伝を物理削除しない。

### red-transfer-black-2

Red Transfer は、黒伝と赤伝の履歴を積み増すことで訂正や取消を表現する。

### physical-delete-transfer-red-destination-row-black-immutable

Red Transfer Is Immutable-Only: `immutable transfer model` では、転送先行を直接更新または物理削除しない。 訂正や取消が必要になった場合、既に転送されている黒伝を反転した赤伝を追加する。 この積み増しにより、転送先行の履歴を残したまま訂正や取消を表現できる。 `mutable transfer model` では、転送先行を直接更新または `Physical Delete Transfer` で削除する。 そのため、`mutable transfer model` では Red Transfer は発生しない。

### red-transfer-destination-row-source-black-target-state

Red Transfer Needs Active Black: 赤伝は、反転対象となる黒伝がなければ作れない。 Red Transfer は、`Active Black` を参照して、どの黒伝を反転対象にするかを決める。 Red Transfer が成功した後、その黒伝は既に取り消された状態になるため、`Active Black` ではなくなる。 Red Transfer が成功した場合、生成された赤伝は反転対象だった既存の転送先行を転送元として追跡できる必要がある。

### red-transfer-destination-row-source-black-target-reference

Red Transfer Needs Sign-Reversal Targets: 赤伝は、黒伝を反転した転送先行である。 そのため、赤伝を作るには、数量や金額など、少なくとも1つの符号反転対象が必要である。 符号反転対象がない場合、黒伝を反転した赤伝として何を追加するのかが概念上成立しない。 赤伝は既に転送されている黒伝から作る。赤伝時に転送元行の現在値を参照して赤伝を作る概念ではない。

### destination-red-transfer-setting-produce-not-define-sql

Red Transfer Is Not the SQL Generation Rule: Red Transfer は、`immutable transfer model` における取消や訂正の概念である。 符号反転する列、引き継ぐ列、実際の SQL 生成手順は、この文書では定義しない。 それらは `Destination` の転送先仕様、`Transfer Setting` との接続、または後続の転送実装で扱う。

### Defined relationships

- active-black / uses: Red Transfer は反転対象となる Active Black を必要とする。

- destination / uses: Red Transfer は Destination の transfer model と赤伝列情報に依存する。

- lineage / records: 成功した Red Transfer は、反転対象の既存転送先行と生成された赤伝の対応を Lineage として記録する。

- active-black / is-distinct-from: Red Transfer は反転する赤伝を追加し、Active Black は反転対象となる現在有効な黒伝を特定する。

## transfer-execution

Source: docs/concepts/transfer-execution/concept.json

転送実行記録をプロセスヘッダーとして生成し、転送作業対象へ転送対象判定を適用して判定結果を実行するメインルーチン

### transfer-execution

Transfer Execution とは、データ転送処理のメインルーチンである。

### transfer-execution-run-arguments-record

Transfer Execution は、実行引数を `Transfer Run` として記録する。

### transfer-execution-run-arguments-record-2

`Transfer Run` は、Transfer Execution の実行引数記録兼プロセスヘッダーである。

### transfer-execution-run

`Transfer Run` は、Transfer Execution に従属する。

### destination-link-transfer-execution-setting-run-arguments-target

Transfer Execution の外部入力は対象 `Transfer Setting` と実行引数であり、`Destination` や `Destination Link` は `Transfer Setting` から辿る。

### transfer-execution-setting-target

Transfer Execution は、対象 `Transfer Setting` に従って転送する。

### transfer-execution-run-record

Transfer Execution は、`Transfer Run` に記録された引数を転送条件として利用してよい。

### transfer-execution-run-target

Transfer Execution は、転送対象となる行を `Transfer Run` の引数として直接受け取らない。

### dirty-key-transfer-execution-change-detection-history-management

Transfer Execution は、`Dirty Key` Management に蓄積された変更検知履歴を `Work Item` として固定化する。

### dirty-key-processing-transfer-execution-record-work-item

Transfer Execution は、`Work Item` を作るとき `Dirty Key Processing` に記録済みの `Dirty Key` を除外する。

### transfer-execution-decide-work-item

Transfer Execution は、`Work Item` に `Transfer Target Decision` を適用し、その結果を実行する。

### transfer-execution-run-arguments-state-trace-create

Transfer Execution は、実行引数を `Transfer Run` として作成し、実行開始時の引数と進捗状態を追跡できるようにする。

### transfer-execution-setting-target-reference

Transfer Execution は、対象 `Transfer Setting` を参照する。

### destination-link-transfer-execution-setting-reference-belongs

Transfer Execution は、`Transfer Setting` に紐づく `Destination Link` 群と、その先の `Destination` 群を参照する。

### dirty-key-transfer-execution-management-work-item

Transfer Execution は、`Dirty Key` Management に蓄積された行を `Work Item` として固定化する。

### transfer-execution-decide-work-item-2

Transfer Execution は、`Work Item` が持つ転送対象判定の結果をもとに、実際の転送処理へ進める。

### transfer-execution-source-exists

Transfer Execution は、転送元の現在値が存在するかどうかを確認する。

### transfer-execution-exists-active-black

Transfer Execution は、既存の `Active Black` が存在するかどうかを確認する。

### black-transfer-destination-physical-delete-red-execution-decide

Transfer Execution は、`Transfer Target Decision` の結果に従って `Black Transfer`、`Red Transfer`、`Physical Delete Transfer`、または no-op を実行する。

### black-transfer-lineage-red-execution-create-immutable-model

Transfer Execution は、`immutable transfer model` では `Lineage` 作成を伴う `Black Transfer` または `Red Transfer` を選択できるようにする。

### dirty-key-processing-transfer-execution-processed-state-record

Transfer Execution は、転送が終わった `Work Item` を `Dirty Key Processing` に記録し、処理済みとして扱える状態にする。

### not-transfer-execution-run

Transfer Execution は、`Transfer Run` を事前に積まれた実行待ち項目として扱わない。

### not-dirty-key-transfer-execution-processed-state

Transfer Execution は、`Dirty Key` 自体に処理済み状態を書き込まない。

### not-destination-transfer-execution-setting

Transfer Execution は、`Transfer Setting` の内容や `Destination` の転送先仕様を変更しない。

### not-dirty-key-transfer-execution-define

Transfer Execution は、`Dirty Key` の登録方法を定義しない。

### not-black-transfer-lineage-red-execution-define-active

Transfer Execution は、`Black Transfer`、`Red Transfer`、`Active Black`、`Lineage` の保存形式を定義しない。

### not-transfer-execution-manage

Transfer Execution は、スケジューリングそのものを管理しない。

### not-transfer-execution-produce-define-sql

Transfer Execution は、SQL 生成手順や SQL 実行手順の具体形を定義しない。

### transfer-execution-run-2

Transfer Execution は、必ず `Transfer Run` をプロセスヘッダーとして持つ。

### transfer-execution-run-produce

Transfer Execution は、`Transfer Run` を生成する。

### transfer-execution-setting-target-requires-one

Transfer Execution は、必ず1つの `Transfer Setting` を対象にする。

### destination-link-transfer-execution

Transfer Execution は、`Destination` や `Destination Link` を外部入力として要求しない。

### transfer-execution-run-target-row

Transfer Execution は、転送対象行を `Transfer Run` の引数として受け付けない。

### dirty-key-transfer-execution-not-decide

Transfer Execution は、`Dirty Key` を変更通知として扱い、`Dirty Key` だけで転送操作を決定しない。

### dirty-key-transfer-execution-work-item

Transfer Execution は、`Dirty Key` を `Work Item` として固定化してから転送処理に使う。

### dirty-key-processing-transfer-execution-processed-reference-work

Transfer Execution は、`Work Item` を作る前に `Dirty Key Processing` を参照して処理済み `Dirty Key` を除外する。

### dirty-key-transfer-execution-processed-state

Transfer Execution は、`Dirty Key` 自体に処理済み状態を書き込まない。

### dirty-key-processing-transfer-execution-record-work-item-2

Transfer Execution は、転送が終わった `Work Item` を `Dirty Key Processing` に記録する。

### transfer-execution-source-decide-active-black

Transfer Execution は、転送対象判定の結果を転送処理の判断材料として扱う。

### destination-transfer-execution-model

Transfer Execution は、`Transfer Target Decision` の結果に従って転送表現を実行する。

### black-transfer-lineage-red-immutable-model

`immutable transfer model` では、`Lineage` は `Black Transfer` または `Red Transfer` の成功結果として扱う。

### red-transfer-immutable-model-active-black

`immutable transfer model` では、既存の `Active Black` を取り消す場合に `Red Transfer` を使う。

### black-update-transfer-physical-delete-mutable-model

`mutable transfer model` では、既存行の現在値反映は Black Update Transfer として扱い、取消は `Physical Delete Transfer` として扱う。

### destination-dirty-key-transfer-execution-run-setting-lifecycle

Transfer Execution Owns the Main Routine: Transfer Execution は、転送処理のメインルーチンである。 `Transfer Run` は Transfer Execution の引数記録兼プロセスヘッダーであり、実行全体のライフサイクル状態を保持するが、転送対象判定そのものではない。 `Dirty Key` は変更通知であり、どのように転送するかを決定しない。 そのため、Transfer Execution は `Work Item` に `Transfer Target Decision` を適用し、その判定結果に従って転送表現を実行する。

### transfer-execution-run-setting-source-arguments-context-target

Transfer Run Provides the Execution Context: Transfer Execution は、転送元、転送条件、実行開始時引数を `Transfer Run` として記録する。 `Transfer Run` は、Transfer Execution が生成する実行引数記録兼プロセスヘッダーである。 `Transfer Run` は、進捗管理、監査、デバッグの実行文脈として有用である。 Transfer Execution は対象 `Transfer Setting` を実行し、その実行文脈を `Transfer Run` として残す。

### black-transfer-dirty-key-processing-physical-delete-red

Dirty Key Provides Candidates, Not Operations: `Dirty Key` は、転送元行に何らかの変更が起きた可能性を示す。 `Dirty Key` は変更通知であり、`Black Transfer`、`Red Transfer`、`Physical Delete Transfer`、または no-op を直接表さない。 Transfer Execution は、`Dirty Key` が示す候補を `Work Item` として固定化し、`Transfer Target Decision` を適用する。 Transfer Execution は、処理後に `Dirty Key Processing` へ記録し、`Work Item` を処理済みとして扱える状態にする。

### black-transfer-update-physical-delete-red-execution-source

Transfer Decision Is Applied Through Transfer Target Decision: Transfer Execution は、`Work Item` に `Transfer Target Decision` を適用し、転送要否と転送表現候補の結果を得る。具体的な判定表は `Transfer Target Decision` と Transfer Execution Process Map が扱う。Transfer Execution はその結果に従って、転送をスキップするか、`Black Transfer`、`Red Transfer`、`Physical Delete Transfer` の処理へ進める。

### black-transfer-destination-lineage-red-execution-row-record

Immutable Transfer Produces Traceable Destination Rows: `immutable transfer model` では、転送先行を履歴として積み増す。 そのため、`Black Transfer` または `Red Transfer` が成功した場合、生成された転送先行の由来を `Lineage` として追跡できる必要がある。 Transfer Execution は `Lineage` を直接記録する概念ではなく、`Lineage` 作成を伴う転送表現を選択する。

### Defined relationships

- transfer-run / produces: Transfer Execution は実行引数記録兼プロセスヘッダーとして Transfer Run を生成する。

- transfer-setting / uses: Transfer Execution は Transfer Run が対象にする Transfer Setting に従う。

- destination / uses: Transfer Execution は Destination の transfer model と転送先側ルールを参照する。

- dirty-key / consumes: Transfer Execution は Dirty Key Management の記録を転送候補として消費する。

- dirty-key-processing / uses: Transfer Execution は Work Item 作成前に Dirty Key Processing を参照して処理済み Dirty Key を除外し、処理後に Dirty Key Processing を記録する。

- work-item / produces: Transfer Execution は Dirty Key を Work Item として固定化する。

- work-item / uses: Transfer Execution は Work Item に Transfer Target Decision を適用し、転送要否と転送表現候補を得る。

- active-black / uses: Transfer Execution は Transfer Target Decision の結果に従って黒転送、赤転送、更新、削除、または no-op を実行する。

- black-transfer / uses: Transfer Execution は現在の転送元値を転送先へコピーすべき場合に Black Transfer を実行する。

- red-transfer / uses: Transfer Execution は immutable transfer model で active black row を反転すべき場合に Red Transfer を実行する。

- physical-delete-transfer / uses: Transfer Execution は mutable transfer model の削除ケースで Physical Delete Transfer を使う。

- transfer-target-decision / uses: Transfer Execution は Work Item に Transfer Target Decision を適用し、転送要否と転送表現候補を得る。

## transfer-run

Source: docs/concepts/transfer-run/concept.json

転送実行が生成する実行引数記録兼プロセスヘッダー

### transfer-execution-run-arguments-record-produce

転送実行記録とは、`転送実行` が生成する実行引数記録兼プロセスヘッダーである。

### transfer-execution-run-record

Transfer Run は、`Transfer Execution` の引数を記録する。

### transfer-run-lifecycle-state-hold

Transfer Run は、実行開始時の引数と、実行全体のライフサイクル状態を保持する。

### transfer-run-setting-target-requires-one

Transfer Run は、必ず1つの `Transfer Setting` を対象にする。

### destination-transfer-setting-belongs

`Transfer Setting` が分かれば、その転送設定に紐づく `Destination` 群を特定できる。

### transfer-execution-run

Transfer Run は、`Transfer Execution` に従属する。

### transfer-execution-run-arguments-record-produce-2

Transfer Run は、`Transfer Execution` が生成する実行引数記録兼プロセスヘッダーであり、事前に積まれるキューではない。

### transfer-run-setting

Transfer Run は、どの `Transfer Setting` に対する実行かを示す。

### transfer-run-optional-arguments-hold

Transfer Run は、実行開始時の任意引数を保持する。

### transfer-run-lifecycle-state

Transfer Run は、実行全体のライフサイクル状態を示す。

### transfer-execution-run-context-reference

Transfer Run は、`Transfer Execution` のプロセスヘッダーとして、監査やデバッグで参照できる実行文脈を提供する。

### dirty-key-processing-lineage-transfer-run-unit-reference

Transfer Run は、後続の `Lineage` や `Dirty Key Processing` から参照できる実行単位を提供する。

### transfer-run-record

Transfer Run は、日次、月次、手動、再実行などの実行契機の由来や分類を記録してよい。

### transfer-run-source-hold

Transfer Run は、必要に応じて転送元スナップショットを取った時点を説明できる情報を保持してよい。

### transfer-run-hold

Transfer Run は、必要に応じて実行者、開始日時、終了日時、エラー情報などを保持してよい。

### not-transfer-run-target-row-manage

Transfer Run は転送対象行を直接管理しない。

### not-transfer-run-manage

Transfer Run は、どの行を転送すべきかを管理しない。

### not-transfer-target-context-decide-work-item

転送対象かどうかは、`Transfer Target Decision` で判断する。

### not-destination-transfer-run

Transfer Run は `Destination` の定義を持たない。

### not-transfer-run-source-destination-sql

Transfer Run は転送元 SQL や転送先 SQL を持たない。

### not-lineage-transfer-run-destination-row-trace-manage

Transfer Run は、転送先行の由来追跡を管理しない。

### not-transfer-run-active-black-red-reference-manage

Transfer Run は、赤伝時に参照すべき現在有効な黒を管理しない。

### not-transfer-run-change-detection-history-define

Transfer Run は、変更検知履歴の登録方法を定義しない。

### not-transfer-run-target-row-define

Transfer Run は、転送対象行がどのように固定化されるかの具体手順を定義しない。

### not-transfer-run-manage-2

Transfer Run は、スケジューリングそのものを管理しない。

### transfer-run-setting-target-requires-one-2

Transfer Run は、必ず1つの `Transfer Setting` を対象にする。

### transfer-execution-run-produce

Transfer Run は、`Transfer Execution` によって生成される。

### transfer-execution-run-2

Transfer Run は、`Transfer Execution` に従属する。

### transfer-run-trace-hold

Transfer Run は、実行開始時の引数を後から追跡できる形で保持する。

### transfer-run-setting-base-sql-optional-arguments

Transfer Run の任意引数は、`Transfer Setting` の基礎 SQL で利用される可能性があるが、その解釈は Transfer Run 単独では決まらない。

### transfer-run-target-row

Transfer Run は、転送対象行の正本ではない。

### transfer-run-target-row-2

Transfer Run は、転送対象行を受け付けない。

### dirty-key-processing-lineage-transfer-run-reference

Transfer Run は、`Lineage` や `Dirty Key Processing` から参照可能である必要がある。

### lineage-transfer-run-source-context-reference-hold

Transfer Run が転送元スナップショットの時点を保持する場合、その情報は `Lineage` から参照される実行文脈として扱う。

### destination-transfer-run-lifecycle-state

Transfer Run の状態は、実行全体のライフサイクル状態を示すものであり、個別の実行試行、`Destination` ごとの成否、キーごとの処理結果を表すものではない。

### destination-transfer-execution-run-setting-arguments-target-record

Transfer Run Targets One Transfer Setting: Transfer Run は、`Transfer Execution` が生成する実行引数記録兼プロセスヘッダーである。 Transfer Run は、必ず1つの `Transfer Setting` を対象にする。 `Transfer Setting` が分かれば、その `Transfer Setting` に紐づく `Destination` 群を特定できる。 Transfer Run は、`Transfer Execution` がどの `Transfer Setting` を実行対象にしたかを示す。

### transfer-execution-run-setting-base-sql-optional-arguments

Run Arguments Are Run Conditions: Transfer Run は、`Transfer Execution` の実行開始時任意引数を持ってよい。 任意引数の例: - 処理日 - 対象年月 - 支店 - 顧客 - 実行者 - 再実行理由 - 手動実行フラグ これらの引数は、`Transfer Setting` の基礎 SQL で条件値として利用される可能性がある。 ただし、Transfer Run はそれらの引数をどのように SQL へ反映するかを定義しない。 任意検索条件の具体的な扱いは、`Transfer Setting` の基礎 SQL と SSSQL notation に従う。

### destination-transfer-run-state-status-lifecycle-yaml-created

Run Status Is Run Lifecycle State: Transfer Run は、実行に対する進捗状態を持ってよい。 状態の例: ```yaml run_status: - created - running - succeeded - failed - cancelled ``` この状態は、実行全体の状態を示す。 個別の実行試行、`Destination` ごとの成否、キーごとの処理結果を表すものではない。 状態値の最終的な集合は、後続の実装 Issue で決めてよい。 ただし、Transfer Run の状態は「実行全体の進捗」を表す、という意味を変えてはならない。

### transfer-execution-run-arguments-record-produce-generated

Transfer Run Is Generated by Execution: Transfer Run は、`Transfer Execution` が生成するプロセスヘッダーである。 `Transfer Execution` が Transfer Run を取り出して実行するのではなく、`Transfer Execution` が実行引数を Transfer Run として記録する。

### transfer-run-target-row-context-decide-does-not

Transfer Run Does Not Own Target Rows: Transfer Run は、転送実行の条件を管理する。 Transfer Run は、転送対象行を受け付けるものではない。 どの行を転送すべきかは、`Work Item` の文脈で判断する。 Transfer Run は、転送対象行の正本ではない。

### dirty-key-processing-lineage-transfer-run-source-destination

Transfer Run Is Referenced by Later Records: Transfer Run は、後続の `Lineage` や `Dirty Key Processing` から参照される実行単位である。 `Lineage` は、どの転送元キーが、どの転送先キーへ、どの実行で転送されたかを記録する。 `Lineage` が参照するスナップショットの時点は、Transfer Run の実行文脈として説明される。 Transfer Run は、`Lineage` が参照する実行文脈である。 `Dirty Key Processing` は、どの実行で Dirty Key が処理されたかと、その処理結果を記録する。

### Defined relationships

- transfer-setting / targets: Transfer Run は必ず1つの Transfer Setting を対象にする。

- transfer-setting / must-not-redefine: Transfer Run は Transfer Setting の内容を再定義しない。

- dirty-key / must-not-redefine: Transfer Run は Dirty Key の意味を再定義しない。

## transfer-setting

Source: docs/concepts/transfer-setting/concept.json

転送元データソースを定義し、Destination への接続を管理する設定

### transfer-setting-source

Transfer Setting とは、転送元データソースを表す設定である。

### transfer-setting

Transfer Setting は、名前で一意に特定できる。

### source

転送元データソースは、物理テーブルに基づいてもよいし、クエリに基づいてもよい。

### source-key

`source key` とは、転送元データソースの論理行または再評価単位を識別するキーである。キーは単一キーでも複合キーでもよい。

### transfer-setting-source-key

Transfer Setting は `source key` の定義を持つ。

### destination-source-row-key

転送元データソースは、`Destination` の採番式を使って `destination row key` を投影してよい。

### destination-link-transfer-setting

Transfer Setting は、`Destination Link` を通じて `Destination` へ接続される。

### destination-link-transfer-setting-2

`Destination Link` とは、Transfer Setting のデータソースを特定の `Destination` へ接続するための宛先別設定である。

### transfer-setting-2

Transfer Setting は、転送ルールであり、転送実行そのものではない。

### transfer-setting-source-base-sql

Transfer Setting は、転送元データソースを抽出する基礎 SQL を持つ。

### transfer-setting-source-key-2

Transfer Setting は、転送元データソースの論理行または再評価単位を特定する `source key` 定義を持つ。

### destination-transfer-setting-row-base-sql

Transfer Setting は、`Destination` の採番式または自然キーを使って、転送先行を識別するための値を基礎 SQL に含めてよい。

### destination-link-transfer-setting-base-sql

Transfer Setting は、基礎 SQL をどの `Destination` へ接続するかを `Destination Link` として管理する。

### destination-link-produce-source-mapping-sql

`Destination Link` は、宛先ごとの実行順、source-to-destination mapping、生成済み転送 SQL、差分比較除外列を持つ。

### not-transfer-setting-change-detection-history-manage

Transfer Setting は変更検知履歴を管理しない。

### not-transfer-setting-change-detection-history-define

Transfer Setting は変更検知履歴の登録方法を定義しない。

### not-transfer-run-setting-create-manage

Transfer Setting は `Transfer Run` の作成、スケジューリング、実行タイミングを管理しない。

### not-transfer-setting-state-manage

Transfer Setting は転送実行状態を管理しない。

### not-transfer-setting-manage

Transfer Setting は転送履歴を管理しない。

### not-transfer-setting-active-black-red-reference-manage

Transfer Setting は赤伝時に参照すべき現在有効な黒を管理しない。

### not-transfer-setting-destination-define

Transfer Setting は転送先テーブルの保存モデルを定義しない。

### not-transfer-setting-base-sql-engine

Transfer Setting は、transfer engine が基礎 SQL に列や採番式を暗黙に追加することを前提にしない。

### transfer-setting-source-base-sql-2

Transfer Setting の基礎 SQL は、転送元データソースの正本である。

### transfer-setting-reference-package

Transfer Setting の名前は、同じ package 内で一意であり、アプリケーションや後続処理から参照できる必要がある。

### transfer-setting-source-reference-decide-key

Transfer Setting の `source key` 定義は、後続の転送処理が同じ転送元データを識別し、二重転送を防止する判断材料として参照できる必要がある。

### destination-transfer-setting-row-base-sql-2

Transfer Setting の基礎 SQL は、転送先行を識別するために `Destination` の採番式または自然キーを使ってよい。

### destination-transfer-setting-base-sql-engine-row-key

transfer engine は、Transfer Setting の基礎 SQL に `destination row key`、採番式、検索条件、転送先列を暗黙に追加しない。

### transfer-setting-destination-base-sql-insert-update-delete

Transfer Setting の基礎 SQL は、転送先への INSERT / UPDATE / DELETE そのものではない。

### base-sql-produce-sssql-guide-overview-where

任意検索条件は、基礎 SQL の SSSQL notation として表現する。転送 SQL 生成側が WHERE 条件を暗黙に追加しない。

### destination-link-transfer-setting-3

Transfer Setting と `Destination` の接続は、`Destination Link` として管理する。

### destination-link-transfer-setting-produce-sql

生成済み転送 SQL は、Transfer Setting 単体ではなく、`Destination Link` 単位で管理する。

### destination-link-transfer-setting-row-source-base-sql

Transfer Setting Represents a Data Source: Transfer Setting は、転送先ではなく転送元データソースを定義する。 転送元データソースは、物理テーブルをそのまま表してもよいし、複数テーブルや条件を含むクエリとして表してもよい。 転送元データソースは、後続の転送処理が同じ転送元データを識別できるように `source key` 定義を持つ。 `source key` は、転送元データソースの論理行または再評価単位を識別するキーである。これは物理テーブルの主キーそのものとは限らない。 これは Transfer Setting が転送指示、転送処理、転送結果を管理するという意味ではなく、定義として二重転送防止の判断材料を提供するという意味である。 単一テーブルを転送元データソースにする場合、`source key` はそのテーブルの主キーになることが多い。 集計クエリや選択クエリを転送元データソースにする場合、`source key` は集計単位や再評価単位を識別する自然キーになる。 転送元データソースは、転送先行を識別するための値も含めてよい。たとえば `Destination` が持つ採番式を基礎 SQL 内で使い、`Destination Link` ごとの `destination row key` を投影してよい。 ただし、transfer engine は基礎 SQL を受け取って転送するだけであり、基礎 SQL に採番列や転送先列を暗黙に組み込まない。必要な値は Transfer Setting の基礎 SQL と `Destination Link` の mapping で明示する。 複数の `Destination` へ同じデータソースを流す場合でも、データソース定義は Transfer Setting 側に1つ置き、宛先ごとの差分は `Destination Link` 側に置く。

### destination-link-transfer-execution-run-setting-state-connects

Destination Link Connects a Data Source to a Destination: `Destination Link` は、Transfer Setting のデータソースを特定の `Destination` へ接続するための宛先別設定である。 このリンクは単なる中間テーブルではない。ただし、`Transfer Run`、`Transfer Execution`、実行状態、実行履歴そのものでもない。 `Destination Link` の詳細は、独立した Concept Spec で扱う。

### Defined relationships

- destination / uses: Transfer Setting は Destination Link を通じて Destination へ接続する。

- destination-link / uses: Transfer Setting は宛先別の接続を Destination Link として管理する。

- destination / must-not-redefine: Transfer Setting は Destination の意味を再定義しない。

- dirty-key / must-not-redefine: Transfer Setting は Dirty Key の意味を再定義しない。

## transfer-target-decision

Source: docs/concepts/transfer-target-decision/concept.json

変更キーを候補として受け取り、転送元の現在値、有効黒伝、転送モデル、列の値評価をもとに転送対象かどうかを判定する概念

### dirty-key-is-transfer-candidate

変更キーは転送の候補である。

### dirty-key-is-not-direct-transfer-target

変更キーはそのまま転送するわけではなく、転送対象判定によって転送要否と転送表現の候補を決める。

### transfer-model-changes-decision

転送対象判定は、転送モデルによって判定を変える。

### ignored-columns-owned-by-destination-link

比較対象外列は、宛先別の設定として転送先リンクが持つ。

### immutable-no-active-black-is-insert-candidate

immutable transfer model で転送元の現在行が存在し、有効黒伝がなければ、追加転送候補として扱う。

### immutable-no-source-no-active-black-is-no-op

immutable transfer model で転送元の現在行と有効黒伝が両方存在しない場合、変更キーを skipped / no_op として処理済みにし、以後の再評価対象から外す。初回黒伝転送前の削除と取消済みキーの再Dirty化を含む。転送元が再出現した場合は、新しく登録された変更キーで現在状態を再評価する。イベント履歴は逐次再生しない。

### immutable-active-black-is-red-candidate

immutable transfer model で有効黒伝があれば、赤伝転送候補として扱う。

### red-candidate-needs-column-evaluation

赤伝転送候補では、列の検査を行い、比較対象外列以外が変更されている場合に転送対象として扱う。

### mutable-no-active-black-is-insert-candidate

mutable transfer model で有効黒伝がなければ、追加転送候補として扱う。

### mutable-active-black-is-update-candidate

mutable transfer model で有効黒伝があれば、更新転送候補として扱う。

### update-candidate-needs-column-evaluation

更新転送候補では、列の検査を行い、比較対象外列以外が変更されている場合に転送対象として扱う。

### insert-only-no-active-black-is-insert-candidate

insert_only transfer model で転送元の現在行が存在し、有効黒伝がなければ、一度だけ Black Insert する追加転送候補として扱う。

### insert-only-active-black-is-no-op

insert_only transfer model で有効黒伝が存在する場合は、転送元の現在行の存在や値変更にかかわらず、差分比較を行わず skipped / no_op とする。

### insert-only-no-source-no-active-black-is-no-op

insert_only transfer model で転送元の現在行と有効黒伝が両方存在しない場合は skipped / no_op とし、後で転送元が現れた場合は新しい Dirty Key で再評価する。

### ignored-columns-only-is-no-transfer

比較対象外列だけが変わっている場合は、転送対象として扱わない。 日付下限制御などの補正後にDestinationへ保持する比較対象列の値が同一ならno-opとする。補正前の日付だけの変更を転送差分にしない。元日付をoriginal_date等の別の業務列へ明示的に保持する場合は、その列も差分比較除外でない限り比較する。元日付の共通二重管理は要求しない。

### not-dirty-key-registration

転送対象判定は、変更キーの登録方法を定義しない。

### not-column-comparison-expression

転送対象判定は、列の具体的な比較式、SQL、NULL 比較、型変換規則を定義しない。

### not-transfer-operation-storage

転送対象判定は、黒伝転送、赤伝転送、物理削除転送の保存形式や実行手順を定義しない。

### Defined relationships

- dirty-key / uses: 変更キーを転送候補として受け取るため。

- active-black / uses: 有効黒伝の有無が追加、赤伝転送、更新転送、またはinsert_onlyの作成済みno-op判定材料になるため。

- destination / uses: 転送先仕様が持つ transfer model によって判定が変わるため。

- destination-link / uses: 宛先別の比較対象外列を参照し、列の値評価で転送要否を判断するため。

- red-transfer / supports: immutable transfer model で有効黒伝がある場合、列の値評価を通って赤伝転送候補になるため。

- black-transfer / supports: 追加転送候補と mutable transfer model の更新転送候補が黒伝転送側の表現につながるため。

- work-item / supports: 転送作業対象に転送要否と転送表現候補の判断材料を与えるため。

## work-item

Source: docs/concepts/work-item/concept.json

変更キーを転送設定の文脈で固定化し、転送対象判定に必要な文脈と判定結果を運ぶ作業対象

### dirty-key-work-item-target

Work Item とは、`Dirty Key` から固定化された転送作業対象である。

### dirty-key-work-item

Work Item は、`Dirty Key` そのものではない。

### dirty-key-transfer-setting-context-work-item

Work Item は、`Dirty Key` を特定の `Transfer Setting` の文脈で評価する。

### destination-link-transfer-setting-context-work-item

Work Item は、必要に応じて `Transfer Setting` と `Destination Link` の文脈で評価される。

### decide-work-item

Work Item は、固定化されただけでは転送に使えない。転送対象判定が必要である。

### destination-dirty-key-source-decide-active-black-transfer

Work Item は、`Dirty Key`、転送元の現在値、`Active Black`、`Destination` の transfer model を転送対象判定の文脈として持つ。

### decide-transfer-model-route-work-item

Work Item は、転送対象判定の結果として転送要否と転送表現候補を保持できる。

### destination-link-dirty-key-transfer-setting-context-source

Work Item は、同じ `Transfer Setting`、`Destination Link`、`source key` の文脈で重複 `Dirty Key` を判定できる必要がある。

### dirty-key-processed-work-item

Work Item は、処理済みかどうかを `Dirty Key` へ書き戻さない。

### dirty-key-processing-processed-record-work-item

Work Item の処理済み記録は、`Dirty Key Processing` に残す。

### dirty-key-target-work-item

Work Item は、`Dirty Key` から処理対象を固定化する。

### dirty-key-trace-work-item

Work Item は、どの `Dirty Key` に由来するかを追跡できる必要がある。

### transfer-setting-context-trace-decide-work-item

Work Item は、どの `Transfer Setting` の文脈で判断されたかを追跡できる必要がある。

### destination-link-context-trace-decide-work-item

Work Item は、必要に応じてどの `Destination Link` の文脈で判断されたかを追跡できる必要がある。

### source-hold-exists-decide-work-item

Work Item は、転送元の現在値が存在するかどうかを判断材料として保持できる必要がある。

### hold-exists-decide-active-black-work-item

Work Item は、`Active Black` が存在するかどうかを判断材料として保持できる必要がある。

### decide-transfer-model-work-item

Work Item は、transfer model を転送対象判定の入力文脈として持つ。

### black-insert-transfer-update-physical-delete-red-execution

Work Item は、`Transfer Execution` が転送対象判定の結果に従って `Black Transfer`、`Red Transfer`、`Physical Delete Transfer`、または no-op を実行できるようにする。

### dirty-key-processing-processed-reference-work-item

Work Item は、`Dirty Key Processing` を参照して処理済み `Dirty Key` を除外できる必要がある。

### destination-link-dirty-key-transfer-setting-context-decide

Work Item は、同じ `Transfer Setting`、`Destination Link`、`source key` の文脈で重複する `Dirty Key` を無視する判断を持てる必要がある。

### dirty-key-processing-processed-record-work-item-2

Work Item の処理が終わった後、`Dirty Key Processing` に処理済み記録を残せる必要がある。

### not-dirty-key-change-detection-history-management-work

Work Item は、`Dirty Key` Management の変更検知履歴を変更しない。

### not-dirty-key-processed-state-work-item

Work Item は、`Dirty Key` 自体に処理済み状態を書き込まない。

### not-dirty-key-define-work-item

Work Item は、`Dirty Key` の登録方法を定義しない。

### not-transfer-run-arguments-record-work-item

Work Item は、`Transfer Run` の実行引数記録兼プロセスヘッダーを代替しない。

### not-dirty-key-processing-processed-record-work-item

Work Item は、`Dirty Key Processing` の処理済み記録を代替しない。

### not-black-transfer-lineage-red-define-active-work

Work Item は、`Black Transfer`、`Red Transfer`、`Active Black`、`Lineage` の保存形式を定義しない。

### not-produce-define-sql-work-item

Work Item は、転送 SQL の生成手順や実行手順を定義しない。

### dirty-key-work-item-2

Work Item は、`Dirty Key` を固定化して作られる。

### dirty-key-work-item-3

Work Item は、少なくとも1つの `Dirty Key` に由来する。

### dirty-key-processed-state-management-work-item

Work Item は、`Dirty Key` の処理済み状態を `Dirty Key` Management に書き戻さない。

### dirty-key-processing-processed-work-item

Work Item は、`Dirty Key Processing` にある `Dirty Key` を処理済みとして除外する。

### destination-link-dirty-key-transfer-setting-context-decide-2

Work Item は、同じ `Transfer Setting`、`Destination Link`、`source key` の文脈で既に同じ判定結果として扱われた重複 `Dirty Key` を無視できる。

### dirty-key-processing-processed-record-work-item-3

Work Item の処理済み記録は、`Dirty Key Processing` に残す。

### dirty-key-transfer-setting-decide-work-item

同じ `Dirty Key` でも、`Transfer Setting` が異なれば転送対象判定の結果は異なり得る。

### destination-link-dirty-key-decide-transfer-model-work

同じ `Dirty Key` でも、`Destination Link` や transfer model が異なれば転送対象判定の結果は異なり得る。

### dirty-key-decide-work-item

Work Item は、`Dirty Key` だけで転送判断を決めない。

### destination-source-decide-active-black-transfer-model-work

Work Item は、転送元の現在値、`Active Black`、`Destination` の transfer model を転送対象判定の材料として扱う。

### transfer-execution-decide-route-work-item

Work Item は、転送対象判定の結果を持つ。これがない場合、`Transfer Execution` はどの転送表現を成立させるべきかを判断できない。

### transfer-execution-work-item-immutable-route-mutable

`Transfer Execution` は、Work Item に保持された転送対象判定の結果をもとに、必要な転送操作だけを成立させる。

### dirty-key-transfer-execution-change-detection-history-target

Dirty Key Must Be Fixed Before Transfer: `Dirty Key` Management は、変更検知履歴として常に追記され続ける。 `Dirty Key` は、同じキーに対して複数回記録されてよい。 そのため、`Transfer Execution` が処理するには、どの `Dirty Key` を今回の作業対象として扱うかを固定化する必要がある。 Work Item は、その固定化された作業対象である。

### destination-dirty-key-source-reference-decide-fixed-still

Fixed Dirty Key Still Needs Transfer Target Decision: `Dirty Key` は変更通知であり、転送操作を表さない。 `Dirty Key` を Work Item として固定化しただけでは、まだ転送に使えない。 Work Item は、転送対象判定に必要な転送元の現在値、`Active Black`、`Destination` の transfer model などの文脈を揃える。具体的な判定式と転送表現候補の正本は `Transfer Target Decision` が所有する。

### black-insert-transfer-update-dirty-key-physical-delete

Decision Categories Belong to Transfer Target Decision: Work Item は判定対象と判定結果を運ぶが、no-op、追加転送候補、赤伝転送候補、更新転送候補、物理削除転送候補などの分類規則を所有しない。これらの分類は `Transfer Target Decision` と Transfer Execution Process Map が扱う。

### destination-link-dirty-key-processing-transfer-run-setting

Dirty Key Does Not Own Processed State: `Dirty Key` は変更検知履歴であり、`Transfer Setting` ごとの処理状態ではない。 同じ `Dirty Key` でも、`Transfer Setting` が異なれば転送対象判定の結果は異なり得る。 そのため、`Dirty Key` 自体に処理済みかどうかを書き込んではならない。 Work Item の処理済み記録は、`Dirty Key Processing` に残す。 `Dirty Key Processing` は、`Dirty Key` ID、`Destination Link` ID、処理結果、`Transfer Run` を記録し、`Transfer Setting` と `Destination Link` の文脈で処理済みを追跡できる必要がある。

### dirty-key-processing-transfer-execution-processed-state-record

Transfer Execution Uses Work Items: `Transfer Execution` は、Work Item に保持された転送対象判定の結果をもとに、必要な転送操作だけを成立させる。 転送が終わったら、`Transfer Execution` は `Dirty Key Processing` に記録し、Work Item を処理済みとして扱える状態にする必要がある。 これは、同じ Work Item を複数回転送しないためである。

### Defined relationships

- dirty-key / depends-on: Work Item は Dirty Key を転送作業として固定化して作られる。

- dirty-key-processing / uses: Work Item 作成では、同じ setting と destination-link の文脈で Dirty Key Processing 記録がある Dirty Key を除外する。

- transfer-setting / depends-on: Work Item は Transfer Setting の文脈で転送対象判定に渡される。

- active-black / uses: Work Item は転送対象判定の入力文脈として Active Black の有無を持つ。

- destination / uses: Work Item は転送対象判定の入力文脈として Destination の transfer model を持つ。

- dirty-key / is-distinct-from: Dirty Key は変更検知履歴であり、Work Item は転送判断を持つ固定化された作業対象である。

- lineage / depends-on: Work Item は重複、再転送、削除相当の判断で Lineage の影響を受けることがある。

- transfer-target-decision / uses: Work Item は Transfer Target Decision の入力文脈と判定結果を運ぶ。
