- Primary database: PostgreSQL

Raw SQL Rules covers executable application SQL. `source_sql_body` and generated transfer SQL columns are currently stored as bound data by the registration features; this does not authorize executing arbitrary submitted SQL. Future execution must establish the application-owned review/approval boundary under the existing concepts and Rules. DDL and documentation generation remain distinct from runtime query mirrors.
